public class Nodo {
    int valor;
    Nodo siguiente, anterior;

    public Nodo(int valor) {
        this.valor = valor;
        this.siguiente = this.anterior = null;
    }
}

